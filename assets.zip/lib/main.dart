import 'package:flutter/material.dart';
import 'package:project/page/Login.dart';

main(){
  runApp(MaterialApp(
    home: Login(),
    debugShowCheckedModeBanner: false,
  )
  );
}

